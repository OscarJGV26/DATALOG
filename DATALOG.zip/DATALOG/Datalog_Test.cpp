#include "DATALOG.h"
#include "Timing.h"
 #include <unistd.h>
#include <math.h>
DATALOG datalog;
static void handler(int sig, siginfo_t *si, void *uc)
{
    clock_gettime(CLOCK_REALTIME,&real_time_clock);
    rt_clock=real_time_clock.tv_sec+(double)real_time_clock.tv_nsec/1000000000.0f;
    real_period=rt_clock-timer;
    timer=rt_clock;
    execute=1;
}
void timer_init(double sample_time){
    sa.sa_flags = SA_SIGINFO;
   sa.sa_sigaction = handler;
   sigemptyset(&sa.sa_mask);
   sigaction(SIG, &sa, NULL);
   sigemptyset(&mask);
   sigaddset(&mask, SIG);
   sigprocmask(SIG_SETMASK, &mask, NULL);
   sev.sigev_notify = SIGEV_SIGNAL;
   sev.sigev_signo = SIG;
   sev.sigev_value.sival_ptr = &timerid;
   timer_create(CLOCKID, &sev, &timerid);
   freq_nanosecs=(long long)(sample_time*1000000000);
   its.it_value.tv_sec = freq_nanosecs / 1000000000;
   its.it_value.tv_nsec = freq_nanosecs % 1000000000;
   its.it_interval.tv_sec = its.it_value.tv_sec;
   its.it_interval.tv_nsec = its.it_value.tv_nsec;
   timer_settime(timerid, 0, &its, NULL);
   sigprocmask(SIG_UNBLOCK, &mask, NULL);
}
int main(int argc, char *argv[]){
    datalog.begin();
    double amplitude,frequency,sampling_time, Time;
    sscanf(argv[1],"%lf",&amplitude);
    sscanf(argv[2],"%lf",&frequency);
    sscanf(argv[3],"%lf",&sampling_time);
    sscanf(argv[4],"%lf",&Time);
    timer_init(sampling_time);
    long iterations= (long) Time/sampling_time;
    double test_signal;
    double pi=3.141592653;
    double omega=frequency*2*pi;
    float array[10];
    int count=0;
    double sampling_time_precision=0.001;  
    for(long i=0;i<iterations;i++){
        while(execute==0);
        test_signal=amplitude*sin(omega*i*sampling_time);
        for(int j=0;j<10;j++){
            array[j]=(float)test_signal;
        }
        array[0]=real_period;
        array[1]=real_period-sampling_time;
        if(array[1]>sampling_time_precision||array[1]<-sampling_time_precision){
            printf("Real Period is %10.10f\n",real_period);
            count++;
        }
        datalog.write(array,array,array,array,array,array,array,array,array);
        printf("Writing...\n");
        sleep(1);
    }
    for(int i=0;i<100;i++)datalog.close();
    count-=2;
    printf("The system recorded %d violations of the required sampling time\n", count);
    printf("Program Terminated.\n");
    
}